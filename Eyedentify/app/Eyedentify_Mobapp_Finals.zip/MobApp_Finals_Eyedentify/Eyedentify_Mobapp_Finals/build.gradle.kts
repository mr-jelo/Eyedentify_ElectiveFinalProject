plugins {
    kotlin("android") version "1.9.10" apply false
    id("com.android.application") version "8.7.2" apply false
    kotlin("kapt") version "1.9.21" apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
}

buildscript {
    extra["kotlin_version"] = "1.9.10"
    dependencies {
        classpath("com.android.tools.build:gradle:7.4.0")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:${property("kotlin_version")}")
    }
}

allprojects {
}



