package com.logronio.eyedentify_mobapp_finals

import android.Manifest
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.graphics.ImageDecoder
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.core.view.GravityCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.logronio.eyedentify_mobapp_finals.databinding.ActivityMainBinding
import com.logronio.eyedentify_mobapp_finals.databinding.DialogFullImageBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {
    private lateinit var viewBinding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var historyAdapter: ScanHistoryAdapter

    // Firebase components
    private lateinit var firebaseDb: FirebaseFirestore
    private lateinit var scanFirebaseRepository: ScanRepository

    private var imageCapture: ImageCapture? = null
    private var camera: Camera? = null
    private var preview: Preview? = null
    private var isScanning = false

    private val requiredPermissions = arrayOf(Manifest.permission.CAMERA)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.all { it.value }) {
            startCameraPreview()
        } else {
            showPermissionDeniedDialog()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        initializeComponents()
        setupUI()
        checkPermissionsAndStartCamera()

        // Initialize Firebase
        initializeFirebase()

        // Test Firebase connection (you can comment this out later)
        testFirebaseConnection()
    }

    private fun initializeComponents() {
        cameraExecutor = Executors.newSingleThreadExecutor()
        historyAdapter = ScanHistoryAdapter { scanResult ->
            showFullImage(scanResult)
        }
    }

    private fun initializeFirebase() {
        // Initialize Firebase
        firebaseDb = FirebaseFirestore.getInstance()
        scanFirebaseRepository = ScanRepository()

        Log.d(TAG, "Firebase initialized successfully")
    }

    private fun testFirebaseConnection() {
        // Test 1: Simple connection test
        testBasicFirebaseWrite()

        // Test 2: Add sample scan data
        // Uncomment the line below to add sample data
        // addSampleScanData()

        // Test 3: Read data from Firebase
        // testFirebaseRead()
    }

    private fun testBasicFirebaseWrite() {
        val testData = mapOf(
            "test" to "Hello Firebase from MainActivity!",
            "timestamp" to Date(),
            "app_version" to "1.0"
        )

        firebaseDb.collection("connection_test")
            .add(testData)
            .addOnSuccessListener { documentReference ->
                Log.d(TAG, "✅ Firebase connection test successful! Document ID: ${documentReference.id}")
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "Firebase connected successfully!",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "❌ Firebase connection test failed", e)
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "Firebase connection failed: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
    }

    private fun addSampleScanData() {
        lifecycleScope.launch {
            try {
                val sampleScan = ScanResult(
                    imageUri = "content://sample_test_image.jpg",
                    detectedText = "This is a test scan from MainActivity",
                    detectedObjects = listOf("phone", "laptop", "cup", "book"),
                    timestamp = Date()
                )

                scanFirebaseRepository.insert(sampleScan)
                Log.d(TAG, "✅ Sample scan data added to Firebase successfully")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "Sample data added to Firebase!",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error adding sample scan data", e)
                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "Error adding sample data: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun testFirebaseRead() {
        lifecycleScope.launch {
            try {
                scanFirebaseRepository.getAllScans().collect { scanResults ->
                    Log.d(TAG, "📖 Firebase scan results count: ${scanResults.size}")
                    scanResults.forEach { scan ->
                        Log.d(TAG, "Scan: ${scan.detectedText} - Objects: ${scan.detectedObjects}")
                    }

                    if (scanResults.isNotEmpty()) {
                        runOnUiThread {
                            Toast.makeText(
                                this@MainActivity,
                                "Found ${scanResults.size} scans in Firebase",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error reading Firebase data", e)
            }
        }
    }

    private fun setupUI() {
        with(viewBinding) {
            historyRecyclerView.apply {
                layoutManager = LinearLayoutManager(this@MainActivity)
                adapter = historyAdapter
                setHasFixedSize(true)
            }

            // history button
            historyButton.setOnClickListener {
                loadHistoryAndOpenDrawer()
            }

            // scan button
            scanButton.setOnClickListener {
                if (!isScanning) takePictureAndAnalyze()
            }

            // clear history
            clearHistoryButton.setOnClickListener {
                showClearHistoryConfirmation()
            }

            // Long press on scan button to test Firebase (temporary)
            scanButton.setOnLongClickListener {
                showFirebaseTestDialog()
                true
            }
        }

        observeScanHistory()
    }

    // Firebase testing dialog (temporary - remove when testing is done)
    private fun showFirebaseTestDialog() {
        AlertDialog.Builder(this)
            .setTitle("Firebase Testing")
            .setMessage("Choose a Firebase test to run:")
            .setPositiveButton("Add Sample Data") { _, _ ->
                addSampleScanData()
            }
            .setNeutralButton("Test Connection") { _, _ ->
                testBasicFirebaseWrite()
            }
            .setNegativeButton("Read Data") { _, _ ->
                testFirebaseRead()
            }
            .show()
    }

    private fun observeScanHistory() {
        lifecycleScope.launch {
            scanFirebaseRepository.getAllScans()
                .catch { e ->
                    Log.e(TAG, "Error loading scan history", e)
                    Toast.makeText(
                        this@MainActivity,
                        "Error loading history from Firebase",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                .collect { results ->
                    historyAdapter.submitList(results)
                }
        }
    }

    private fun loadHistoryAndOpenDrawer() {
        with(viewBinding) {
            historyLoadingView.visibility = View.VISIBLE
            drawerLayout.openDrawer(GravityCompat.END)

            lifecycleScope.launch {
                scanFirebaseRepository.getAllScans()
                    .catch { e ->
                        Log.e(TAG, "Error loading history", e)
                        historyLoadingView.visibility = View.GONE
                        Toast.makeText(
                            this@MainActivity,
                            "Error loading history from Firebase",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    .collect { results ->
                        historyAdapter.submitList(results)
                        historyLoadingView.visibility = View.GONE
                    }
            }
        }
    }

    private fun showClearHistoryConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Clear History")
            .setMessage("Are you sure you want to clear all scan history from Firebase?")
            .setPositiveButton("Clear") { _, _ ->
                clearHistory()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun clearHistory() {
        lifecycleScope.launch {
            try {
                scanFirebaseRepository.deleteAll()
                Toast.makeText(
                    this@MainActivity,
                    "History cleared from Firebase",
                    Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Log.e(TAG, "Error clearing history", e)
                Toast.makeText(
                    this@MainActivity,
                    "Error clearing history: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun showFullImage(scanResult: ScanResult) {
        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val binding = DialogFullImageBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        lifecycleScope.launch {
            try {
                val bitmap = withContext(Dispatchers.IO) {
                    val uri = scanResult.imageUri.toUri()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        ImageDecoder.decodeBitmap(
                            ImageDecoder.createSource(contentResolver, uri)
                        )
                    } else {
                        @Suppress("DEPRECATION")
                        MediaStore.Images.Media.getBitmap(contentResolver, uri)
                    }
                }
                binding.fullImageView.setImageBitmap(bitmap)
            } catch (e: Exception) {
                Log.e(TAG, "Error loading full image", e)
                Toast.makeText(
                    this@MainActivity,
                    "Error loading image",
                    Toast.LENGTH_SHORT
                ).show()
                dialog.dismiss()
            }
        }

        binding.closeButton.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun checkPermissionsAndStartCamera() {
        when {
            hasPermissions() -> startCameraPreview()
            else -> permissionLauncher.launch(requiredPermissions)
        }
    }

    private fun hasPermissions() = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startCameraPreview() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()
                setupCameraUseCase(cameraProvider)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start camera preview", e)
                Toast.makeText(
                    this,
                    "Error initializing camera",
                    Toast.LENGTH_LONG
                ).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setupCameraUseCase(cameraProvider: ProcessCameraProvider) {
        preview = Preview.Builder().build().also {
            it.setSurfaceProvider(viewBinding.previewView.surfaceProvider)
        }

        imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()

        val cameraSelector = CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK)
            .build()

        try {
            cameraProvider.unbindAll()
            camera = cameraProvider.bindToLifecycle(
                this,
                cameraSelector,
                preview,
                imageCapture
            )
        } catch (e: Exception) {
            Log.e(TAG, "Use case binding failed", e)
        }
    }

    private fun takePictureAndAnalyze() {
        val imageCapture = imageCapture ?: return
        viewBinding.scanButton.isEnabled = false
        showScanningOverlay()

        try {
            val photoFile = createTempImageFile()
            val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

            imageCapture.takePicture(
                outputOptions,
                ContextCompat.getMainExecutor(this),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                        try {
                            Log.d(TAG, "Image saved successfully at ${photoFile.absolutePath}")
                            navigateToResults(photoFile.toUri().toString())
                        } catch (e: Exception) {
                            Log.e(TAG, "Error during navigation: ${e.message}", e)
                            handleCaptureError("Failed to process image: ${e.message}")
                        }
                    }

                    override fun onError(exc: ImageCaptureException) {
                        Log.e(TAG, "Photo capture failed: ${exc.message}", exc)
                        handleCaptureError("Failed to capture image: ${exc.message}")
                    }
                }
            )
        } catch (e: Exception) {
            Log.e(TAG, "Setup for image capture failed: ${e.message}", e)
            handleCaptureError("Camera error: ${e.message}")
        }
    }

    private fun navigateToResults(imageUri: String) {
        val intent = Intent(this, ResultsActivity::class.java).apply {
            putExtra(ResultsActivity.EXTRA_IMAGE_URI, imageUri)
            addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        }
        startActivity(intent)
        viewBinding.scanButton.isEnabled = true
        hideScanningOverlay()
    }

    private fun handleCaptureError(message: String = "An error occurred") {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        viewBinding.scanButton.isEnabled = true
        hideScanningOverlay()
    }

    private fun showScanningOverlay() {
        isScanning = true
        with(viewBinding) {
            scanningOverlay.apply {
                alpha = 0f
                visibility = View.VISIBLE
                animate()
                    .alpha(1f)
                    .setDuration(300)
                    .start()
            }
            statusText.text = "Scanning..."
        }
    }

    private fun hideScanningOverlay() {
        isScanning = false
        with(viewBinding) {
            scanningOverlay.animate()
                .alpha(0f)
                .setDuration(300)
                .withEndAction {
                    scanningOverlay.visibility = View.GONE
                }
                .start()
            statusText.text = "Camera ready"
        }
    }

    private fun createTempImageFile(): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
            .format(Date())
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("IMG_${timeStamp}_", ".jpg", storageDir)
    }

    private fun showPermissionDeniedDialog() {
        AlertDialog.Builder(this)
            .setTitle("Permissions Required")
            .setMessage("Camera permission is required to use this app")
            .setPositiveButton("Settings") { _, _ ->
                openAppSettings()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }

    private fun openAppSettings() {
        Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            startActivity(this)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

    companion object {
        private const val TAG = "MainActivity"
    }
}