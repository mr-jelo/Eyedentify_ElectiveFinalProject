package com.logronio.eyedentify_mobapp_finals

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.*

class ScanRepository {
    private val firestore = FirebaseFirestore.getInstance()
    private val scansCollection = firestore.collection("scans")

    companion object {
        private const val TAG = "ScanRepository"
    }

    // Insert a new scan result to Firebase
    suspend fun insert(scanResult: ScanResult): String {
        return try {
            val scanData = mapOf(
                "imageUri" to scanResult.imageUri,
                "detectedText" to scanResult.detectedText,
                "detectedObjects" to scanResult.detectedObjects,
                "timestamp" to scanResult.timestamp
            )

            val documentReference = scansCollection.add(scanData).await()
            Log.d(TAG, "✅ Scan added to Firebase with ID: ${documentReference.id}")
            documentReference.id
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error adding scan to Firebase", e)
            throw e
        }
    }

    // Get all scans from Firebase
    fun getAllScans(): Flow<List<ScanResult>> = callbackFlow {
        val listener = scansCollection
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "❌ Error listening to scans", error)
                    close(error)
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val scans = snapshot.documents.mapNotNull { document ->
                        try {
                            ScanResult(
                                id = document.id, // Use Firebase document ID
                                imageUri = document.getString("imageUri") ?: "",
                                detectedText = document.getString("detectedText") ?: "",
                                detectedObjects = document.get("detectedObjects") as? List<String> ?: emptyList(),
                                timestamp = document.getTimestamp("timestamp")?.toDate() ?: Date()
                            )
                        } catch (e: Exception) {
                            Log.e(TAG, "Error parsing document ${document.id}", e)
                            null
                        }
                    }
                    trySend(scans)
                }
            }

        awaitClose { listener.remove() }
    }

    // Get a specific scan by ID
    suspend fun getScanById(documentId: String): ScanResult? {
        return try {
            val document = scansCollection.document(documentId).get().await()
            if (document.exists()) {
                ScanResult(
                    id = document.id,
                    imageUri = document.getString("imageUri") ?: "",
                    detectedText = document.getString("detectedText") ?: "",
                    detectedObjects = document.get("detectedObjects") as? List<String> ?: emptyList(),
                    timestamp = document.getTimestamp("timestamp")?.toDate() ?: Date()
                )
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting scan by ID", e)
            null
        }
    }

    // Update a scan
    suspend fun update(scanResult: ScanResult) {
        try {
            val scanData = mapOf(
                "imageUri" to scanResult.imageUri,
                "detectedText" to scanResult.detectedText,
                "detectedObjects" to scanResult.detectedObjects,
                "timestamp" to scanResult.timestamp
            )

            scansCollection.document(scanResult.id).set(scanData).await()
            Log.d(TAG, "✅ Scan updated in Firebase")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error updating scan in Firebase", e)
            throw e
        }
    }

    // Delete a scan
    suspend fun delete(scanResult: ScanResult) {
        try {
            scansCollection.document(scanResult.id).delete().await()
            Log.d(TAG, "✅ Scan deleted from Firebase")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error deleting scan from Firebase", e)
            throw e
        }
    }

    // Delete all scans (be careful with this!)
    suspend fun deleteAll() {
        try {
            val snapshot = scansCollection.get().await()
            for (document in snapshot.documents) {
                document.reference.delete().await()
            }
            Log.d(TAG, "✅ All scans deleted from Firebase")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error deleting all scans from Firebase", e)
            throw e
        }
    }

    // Get count of scans
    suspend fun getCount(): Int {
        return try {
            val snapshot = scansCollection.get().await()
            snapshot.size()
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting scan count", e)
            0
        }
    }
}