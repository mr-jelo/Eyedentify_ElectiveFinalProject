package com.logronio.eyedentify_mobapp_finals

import java.util.Date

data class ScanResult(
    val imageUri: String = "",
    val detectedText: String? = null,
    val detectedObjects: List<String>? = null,
    val timestamp: Date = Date()
)
